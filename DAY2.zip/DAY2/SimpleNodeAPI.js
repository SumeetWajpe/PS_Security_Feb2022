const express = require("express");
const app = express();
var cors = require("cors");
const port = 3000;

//app.use(cors()); // not the best practise ! exposes all endpoints !

app.get("/", (req, res) => {
  //   res.send("Hello World!");
  res.sendFile("Products.html", { root: __dirname });
});

app.get("/products", cors(), (req, res) => {
  var products = [
    { id: 1, title: "Laptop" },
    { id: 2, title: "Watch" },
  ];
  res.json(products);
});

app.get("/courses", (req, res) => {
  var courses = [
    { id: 1, title: "React" },
    { id: 2, title: "Angular" },
  ];
  res.json(courses);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
